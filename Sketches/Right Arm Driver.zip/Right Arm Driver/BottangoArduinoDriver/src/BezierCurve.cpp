
#include "BezierCurve.h"
#include "Arduino.h"
#include "Log.h"
#include "../BottangoArduinoConfig.h"

BezierCurve::BezierCurve() : Curve()
{
}