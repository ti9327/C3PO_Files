#include "Curve.h"

Curve::Curve()
{
}