#ifndef FreeRam_h
#define FreeRam_h

void printFreeRam();

#endif