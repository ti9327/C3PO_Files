#ifndef BOTTANGOARDUINO_CURVE_H
#define BOTTANGOARDUINO_CURVE_H

class Curve
{
public:
    Curve();
};
#endif